package com.ptpn.surveykayuaro.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}