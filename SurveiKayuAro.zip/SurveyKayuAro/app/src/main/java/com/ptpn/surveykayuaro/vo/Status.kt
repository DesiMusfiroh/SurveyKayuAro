package com.ptpn.surveykayuaro.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}